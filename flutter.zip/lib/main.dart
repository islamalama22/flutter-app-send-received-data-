import 'dart:async';          
import 'dart:io';          

import 'package:flutter/material.dart';          
import 'package:mqtt_client/mqtt_client.dart';          
import 'package:mqtt_client/mqtt_server_client.dart';          

void main() => runApp(MQTTApp());          

class MQTTApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LineDrawingPage(),
    );          
  }
}

class LineDrawingPage extends StatefulWidget {
  @override
  _LineDrawingPageState createState() => _LineDrawingPageState();          
}

class _LineDrawingPageState extends State<LineDrawingPage> {
  final _streetLengthController = TextEditingController();          
  final _streetWidthController = TextEditingController();          
  final _lineNumberController = TextEditingController();          
  final _lineLengthController = TextEditingController();          
  final _distanceController = TextEditingController();          
  final _leftRightMovementController = TextEditingController();          
  final _frontBackMovementController = TextEditingController();          

  String _lineColor = 'White';          
  String _lineDirection = 'Width';          
  String _connectionStatus = 'Disconnected';          
  int _is_connected = 0;          

  late MqttServerClient client;          
  Timer? _reconnectTimer;          

  // Variables to store received messages
  String _obstacleMessage = 'No messages yet';          
  String _finishDrawingMessage = 'No messages yet';          
  String _colorIntensityMessage = 'No messages yet'; 
  
  String stop_case = "yes";       

  @override
  void initState() {
    super.initState();          
    _setupMQTT();          
  }

  Future<void> _setupMQTT() async {
    client = MqttServerClient('broker.hivemq.com', 'ppu_flutter_client_${DateTime.now().millisecondsSinceEpoch}');          
    client.port = 1883;          
    client.logging(on: true);          
    client.keepAlivePeriod = 60;          
    client.onConnected = _onConnected;          
    client.onDisconnected = _onDisconnected;          
    client.onSubscribed = (String topic) {
      print('Subscribed to topic: $topic');          
    };          

    try {
      await client.connect();          
      setState(() {
        _connectionStatus = 'Connected';          
        _is_connected = 1;          
      });          
      _subscribeToTopics();          
    } on NoConnectionException catch (e) {
      _handleConnectionError('No connection: $e');          
    } on SocketException catch (e) {
      _handleConnectionError('Socket exception: $e');          
    } catch (e) {
      _handleConnectionError('Connection error: $e');          
    }
  }

  void _handleConnectionError(String error) {
    setState(() {
      _connectionStatus = error;          
      _is_connected = 0;          
    });          
    _startReconnectTimer();          
  }

  void _onConnected() {
    setState(() {
      _connectionStatus = 'Connected';          
      _is_connected = 1;          
    });          
    print('Connected to MQTT broker!');          
  }

  void _onDisconnected() {
    setState(() {
      _connectionStatus = 'Disconnected';          
      _is_connected = 0;          
    });          
    print('Disconnected from MQTT broker.');          
    _startReconnectTimer();          
  }

  void _startReconnectTimer() {
    _reconnectTimer?.cancel();          
    _reconnectTimer = Timer.periodic(Duration(seconds: 10), (timer) async {
      print('Attempting to reconnect...');          
      setState(() {
        _connectionStatus = 'Attempting to reconnect...';          
        _is_connected = 0;          
      });          
      await _setupMQTT();          
      if (client.connectionStatus?.state == MqttConnectionState.connected) {
        timer.cancel();          
      }
    });          
  }

  void _subscribeToTopics() {
    final topics = ['ppu/-pro--->found/obstacle', 'ppu/-pro--->finish/drawing', 'ppu/-pro--->color/intensity'];          
    for (var topic in topics) {
      client.subscribe(topic, MqttQos.atLeastOnce);          
    }

    client.updates?.listen((List<MqttReceivedMessage<MqttMessage>> messages) {
      final recMessage = messages[0].payload as MqttPublishMessage;          
      final message = MqttPublishPayload.bytesToStringAsString(recMessage.payload.message);          

      setState(() {
        if (messages[0].topic == 'ppu/-pro--->found/obstacle') {
          _obstacleMessage = message;          
        } else if (messages[0].topic == 'ppu/-pro--->finish/drawing') {
          _finishDrawingMessage = message;          
        } else if (messages[0].topic == 'ppu/-pro--->color/intensity') {
          _colorIntensityMessage = message;          
        }
      });          

      print('Received message: $message from topic: ${messages[0].topic}');          
    });          
  }

  void _publishData() {
    if (client.connectionStatus?.state != MqttConnectionState.connected) {
      print('Cannot publish, not connected.');          
      return;          
    }

    final payload = {
      "street_length": _streetLengthController.text,
      "street_width": _streetWidthController.text,
      "line_number": _lineNumberController.text,
      "line_length": _lineLengthController.text,
      "line_color": _lineColor,
      "distance_between_lines": _distanceController.text,
      "left_right_movement": _leftRightMovementController.text,
      "front_back_movement": _frontBackMovementController.text,
      "line_direction": _lineDirection,
    };          

    final data = payload.entries.map((e) => '${e.key}:${e.value}').join(',');          

    final builder = MqttClientPayloadBuilder();          
    builder.addString(data);          

    try {
      client.publishMessage('ppu/-pro--->draw/line', MqttQos.atLeastOnce, builder.payload!);          
      print('Message published: $data');          
    } catch (e) {
      print('Failed to publish message: $e');          
    }
  }
  void _stop() {
    if (client.connectionStatus?.state != MqttConnectionState.connected) {
      print('Cannot publish, not connected.');          
      return;          
    }

    final builder = MqttClientPayloadBuilder();
    builder.addString(stop_case);
    
    if(stop_case=="yes")stop_case="no";
    else stop_case="yes";    

    try {
      client.publishMessage('ppu/-pro--->stop', MqttQos.atLeastOnce, builder.payload!);          
      print('Message published: $stop_case');          
    } catch (e) {
      print('Failed to publish message: $e');          
    }
  }

  @override
  void dispose() {
    _streetLengthController.dispose();          
    _streetWidthController.dispose();          
    _lineNumberController.dispose();          
    _lineLengthController.dispose();          
    _distanceController.dispose();          
    _leftRightMovementController.dispose();          
    _frontBackMovementController.dispose();          
    client.disconnect();          
    _reconnectTimer?.cancel();          
    super.dispose();          
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Street Paint Robot',
          style: TextStyle(
            fontSize: 20, // Adjust the font size as needed
            fontWeight: FontWeight.bold, // Make the title bold
            color: Colors.black, // Title text color
            letterSpacing: 1.5, // Add spacing between letters
          ),
        ),
        centerTitle: true, // Centers the title
        backgroundColor: Color(0xFFFFC300), // Change the app bar background color
        elevation: 4, // Add some shadow
        toolbarHeight: 70, // Customize the height of the AppBar
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _streetLengthController,
                decoration: InputDecoration(labelText: 'Street Length'),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: _streetWidthController,
                decoration: InputDecoration(labelText: 'Street Width'),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: _lineNumberController,
                decoration: InputDecoration(labelText: 'Line Number'),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: _lineLengthController,
                decoration: InputDecoration(labelText: 'Line Length'),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: _distanceController,
                decoration: InputDecoration(labelText: 'Distance Between Lines (in meters)'),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: _leftRightMovementController,
                decoration: InputDecoration(labelText: 'Left/Right Movement'),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: _frontBackMovementController,
                decoration: InputDecoration(labelText: 'Front/Back Movement'),
                keyboardType: TextInputType.number,
              ),
              DropdownButton<String>(
                value: _lineColor,
                items: ['White', 'Yellow']
                    .map((color) => DropdownMenuItem(
                          value: color,
                          child: Text(color),
                        ))
                    .toList(),
                onChanged: (color) {
                  setState(() {
                    _lineColor = color!;          
                  });          
                },
              ),
              DropdownButton<String>(
                value: _lineDirection,
                items: ['Width', 'Length']
                    .map((direction) => DropdownMenuItem(
                          value: direction,
                          child: Text(direction),
                        ))
                    .toList(),
                onChanged: (direction) {
                  setState(() {
                    _lineDirection = direction!;          
                  });          
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _publishData,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFFFC300), // Background color #ffc300
                  foregroundColor: Color(0xFF000000), // Text color #000000
                ),
                child: Text('Publish Data'),
              ),
              ElevatedButton(
                onPressed: _stop,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFFFC300), // Background color #ffc300
                  foregroundColor: Color(0xFF000000), // Text color #000000
                ),
                child: Text('Stop'),
              ),

              SizedBox(height: 20),
              Text(
                'Received Messages:',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              Container(
              
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8),
                  
                ),
                child: Column(
                
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Obstacle: $_obstacleMessage',
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),),
                    Text('Finish Drawing: $_finishDrawingMessage',
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),),
                    Text('Color Intensity: $_colorIntensityMessage',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                      ),),
                                  
                    ],
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Connection Status: $_connectionStatus',
                style: TextStyle(
                  color: _is_connected == 1 ? Colors.green : Colors.red,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );          
  }
}

