package com.example.kobuki_robot_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
